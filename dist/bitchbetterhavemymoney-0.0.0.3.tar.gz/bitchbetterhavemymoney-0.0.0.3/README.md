# bitchbetterhavemymoney
A Python CLI tool to grab your Monnize maaltijdcheques
